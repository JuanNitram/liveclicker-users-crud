<?php
return [
    'quality' => 90,
	'sizes' => [
		'thumb' => [250,250],
	],
	'images_folder' => 'images',
    'documents_folder' => 'documents'
];
